<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo mensaje de contacto</title>
</head>
<body>
    <h1>Nuevo mensaje de contacto</h1>
    <p><strong>Nombre:</strong> <?php echo e($details['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($details['email']); ?></p>
    <p><strong>Número de teléfono:</strong> <?php echo e($details['numero']); ?></p>
    <p><strong>Mensaje:</strong> <?php echo e($details['message']); ?></p>
</body>
</html>
<!-- codigo enviado al corrector y esta perfecto -->
<?php /**PATH C:\Users\Jere\XAMPP\htdocs\proyecto-Gabi-Betti\resources\views/emails/contacto.blade.php ENDPATH**/ ?>